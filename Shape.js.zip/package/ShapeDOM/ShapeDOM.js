/**
 * Copyright ©Summerytime 2019
 * License Under MIT
*/
/**
 *DOM Modules
 */
 function INIT_DOM(){
   
 }
 function INIT_Create_DOM(){
   
 }
 function INIT_Display_DOM(){

 }