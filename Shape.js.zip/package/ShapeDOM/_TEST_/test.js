import { render, renderDom } from '../ShapeDOM';
ShapeDom.renderDom();
ShapeDom.render();