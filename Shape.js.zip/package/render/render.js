/**
 * Copyright ©Summerytime 2019
 * License Under MIT
 */
/**
 * This js is to rend the DOM.
 * It is useful and powerful.
 * It use the APIs,so USE IT BY a PARTTEN LIKE editor.xxxx
 */
'use strict';
/**
 * INIT Render
 */
function renderINIT() {

}

function renderDomINIT() {

}
/**
 * render model
 */
var test = null;
export function render() {
    return test;
}
export function renderDom() {
    return text;
}

export function renderShow() {

}
export function renderExit() {

}
export function renderDisplay() {

}