/**
 * Copyright ©Summerytime 2019
 * License Under MIT
 */

'use strict';
/**
 * Router
 */
var INIT_ROUTER;

function isRouter() {

}

function isPath() {

}

function isFile() {

}

function isMethod() {

}
/**
 * Check Type
 */
function getFileType() {

}

function getMethodName() {

}